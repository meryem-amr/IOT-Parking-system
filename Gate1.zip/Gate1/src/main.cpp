#include <Arduino.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <Keypad.h>
#include <LiquidCrystal_I2C.h>

// ===================== Pin Definitions =====================
// IR Sensors
#define IR_ENTER 2    // Entrance sensor
#define IR_EXIT 4     // Exit gate sensor
#define IR1_PIN 18    // Exit Sensor for Spot 1
#define IR2_PIN 19    // Exit Sensor for Spot 2
#define IR3_PIN 5     // Exit Sensor for Spot 3

// Servo Motor
#define SERVO_PIN 15

// LED Indicator for CO Detection
#define LED_PIN 16

// ===================== Keypad Configuration =====================
#define ROWS 4
#define COLS 4

char keyMap[ROWS][COLS] = {
  { '1', '2', '3', 'A' },
  { '4', '5', '6', 'B' },
  { '7', '8', '9', 'C' },
  { '*', '0', '#', 'D' }
};

byte rowPins[ROWS] = {13, 12, 14, 27}; // Connect to the row pinouts of the keypad
byte colPins[COLS] = {26, 25, 33, 32}; // Connect to the column pinouts of the keypad

Keypad keypad = Keypad(makeKeymap(keyMap), rowPins, colPins, ROWS, COLS);

// ===================== LCD Configuration =====================
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ===================== Servo Configuration =====================
Servo myservo;

// ===================== Global Variables =====================
int spots[3] = {-1, -1, -1};          // Array to track occupied spots (stores spot numbers: 1, 2, 3; -1 means available)
const int maxSpots = 3;                // Maximum number of spots available

// Debounce variables for entrance detection
unsigned long lastEntranceMotionTime = 0;
const unsigned long entranceDebounceDelay = 5000; // 5 seconds debounce

// Debounce variables for exit gate detection
unsigned long lastExitMotionTime = 0;
const unsigned long exitDebounceDelay = 5000; // 5 seconds debounce

// Previous states of exit sensors to detect transitions
int prevSpotExitState[3] = {HIGH, HIGH, HIGH}; // Initialize to HIGH (no car present)
int prevExitGateState = HIGH; // Initialize to HIGH (no car at exit gate)

// ===================== Function Declarations =====================

// Function to check if parking is full
bool isParkingFull();

// Function to check if a specific spot is occupied
bool isSpotOccupied(int spotNumber);

// Function to add a new spot
void addSpot(int spotNumber);

// Function to remove a spot when a car exits
void removeSpot(int spotNumber);

// Function to initialize hardware components
void initializeHardware();

void setup() {
  // Initialize Serial Monitor
  Serial.begin(115200);
  
  // Initialize hardware components
  initializeHardware();
  
  // Initial LCD Display
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Parking System");
  lcd.setCursor(0, 1);
  lcd.print("Initializing...");
  delay(2000); // Show message for 2 seconds
  lcd.clear();
}void loop() {
  
  // ===================== Entrance Detection =====================
  bool entranceMotionDetected = (digitalRead(IR_ENTER) == LOW); // Assuming active LOW
  
  // Debug: Print IR sensor states
  Serial.print("IR_ENTER: ");
  Serial.print(digitalRead(IR_ENTER));
  Serial.print(" | IR_EXIT_GATE: ");
  Serial.println(digitalRead(IR_EXIT));
  
  // Handle entrance motion detection with debounce
  if (entranceMotionDetected && (millis() - lastEntranceMotionTime > entranceDebounceDelay)) { 
    lastEntranceMotionTime = millis(); // Update the last motion time
    Serial.println("Motion detected at Entrance!");
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Motion detected!");
    
    // Check if parking is full
    if (isParkingFull()) {
      Serial.println("Parking is full. No empty spots available.");
      lcd.setCursor(0, 1);
      lcd.print("Parking is FULL");
      delay(5000);  // Notify the user for 5 seconds
      lcd.clear();
    } else {
      // Parking is not full, ask the user to enter a spot
      Serial.println("Please enter the parking spot number (1-3):");
      lcd.setCursor(0, 1);
      lcd.print("Enter 1, 2, or 3:");
      
      int enteredSpot = -1;
      
      while (true) {
        char key = keypad.getKey();  // Get a keypress from the keypad
        
        if (key) {  // If a key is pressed
          // Only accept '1', '2', or '3'
          if (key == '1' || key == '2' || key == '3') {
            enteredSpot = key - '0'; // Convert char to int
            Serial.print("Entered Spot: ");
            Serial.println(enteredSpot);
            
            // Check if the spot is already occupied
            if (isSpotOccupied(enteredSpot)) {
              Serial.print("Spot ");
              Serial.print(enteredSpot);
              Serial.println(" is already taken. Please enter a different spot.");
              lcd.clear();
              lcd.setCursor(0, 0);
              lcd.print("Spot ");
              lcd.print(enteredSpot);
              lcd.setCursor(0, 1);
              lcd.print("is taken");
              delay(2000);  // Show message for 2 seconds
              lcd.setCursor(0, 1);
              lcd.print("Enter 1, 2, or 3:");
            } else {
              // Spot is available, add it to the array
              addSpot(enteredSpot);
              myservo.write(90);  // Open the door (move servo to 90 degrees)
              Serial.println("Door is opening...");
              lcd.clear();
              lcd.setCursor(0, 0);
              lcd.print("Door opening...");
              delay(5000);  // Keep the door open for 5 seconds
              myservo.write(0);  // Close the door (move servo back to 0 degrees)
              lcd.clear();
              lcd.setCursor(0, 0);
              lcd.print("Door closed");
              delay(2000);  // Show door closed message for 2 seconds
              break;  // Exit the loop once the spot is reserved and door opens
            }
          } else {
            // Invalid key pressed
            Serial.println("Invalid input. Please enter a number (1-3).");
            lcd.clear();
            lcd.setCursor(0, 0);
            lcd.print("Invalid input");
            delay(2000);  // Show invalid input message for 2 seconds
            lcd.setCursor(0, 1);
            lcd.print("Enter 1, 2, or 3:");
          }
        }
      }
      
      delay(5000);  // Wait before checking for the next motion
      lcd.clear();
    }
  }
  
  // ===================== Exit Gate Detection =====================
  bool exitGateMotionDetected = (digitalRead(IR_EXIT) == LOW); // Assuming active LOW
  
  Serial.print("IR_EXIT_GATE: ");
  Serial.println(digitalRead(IR_EXIT));
  
  // Handle exit gate motion detection with debounce
  if (exitGateMotionDetected && (millis() - lastExitMotionTime > exitDebounceDelay)) { 
    lastExitMotionTime = millis(); // Update the last motion time
    Serial.println("Motion detected at Exit Gate!");
    lcd.clear();
    lcd.setCursor(0, 0);lcd.print("Exit Gate detected");
    
    // Open the exit gate door
    myservo.write(90);  // Open the door (move servo to 90 degrees)
    Serial.println("Exit Door is opening...");
    lcd.setCursor(0, 1);
    lcd.print("Door opening...");
    delay(5000);  // Keep the door open for 5 seconds
    myservo.write(0);  // Close the door (move servo back to 0 degrees)
    Serial.println("Exit Door is closing...");
    lcd.clear();
    delay(2000);  // Show door closed message for 2 seconds
  }
  
  // ===================== Spot-Specific Exit Detection =====================
  for (int i = 0; i < maxSpots; i++) {
    int sensorPin;
    switch(i) {
      case 0:
        sensorPin = IR1_PIN;
        break;
      case 1:
        sensorPin = IR2_PIN;
        break;
      case 2:
        sensorPin = IR3_PIN;
        break;
      default:
        sensorPin = IR_EXIT; // Fallback (not used in this setup)
    }
    
    // Read current state of the exit sensor
    bool currentState = (digitalRead(sensorPin) == LOW); // Assuming active LOW
    
    // Detect transition from LOW to HIGH (car leaving)
    if (prevSpotExitState[i] == LOW && currentState == HIGH) {
      if (spots[i] != -1) { // If the spot was occupied
        int spotNumber = spots[i]; // Store the spot number before removing
        Serial.print("Car exiting from Spot ");
        Serial.println(spotNumber);
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("Car exiting Spot");
        lcd.setCursor(0, 1);
        lcd.print(spotNumber);
        
        // Remove the spot from the array
        removeSpot(spotNumber);
        
        // Display the empty spot number on LCD
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("Spot ");
        lcd.print(spotNumber);
        lcd.print(" is free");
        delay(5000);  // Show message for 5 seconds
        lcd.clear();
      }
    }
    
    // Update previous state
    prevSpotExitState[i] = currentState;
  }
  
  delay(1000); // Small delay to stabilize the loop
}

// ===================== Function Definitions =====================

// Function to initialize hardware components
void initializeHardware() {
  pinMode(IR_ENTER, INPUT_PULLUP); // Entrance sensor
  pinMode(IR_EXIT, INPUT_PULLUP);  // Exit gate sensor 
  pinMode(IR1_PIN, INPUT_PULLUP);  // Exit Sensor for Spot 1
  pinMode(IR2_PIN, INPUT_PULLUP);  // Exit Sensor for Spot 2
  pinMode(IR3_PIN, INPUT_PULLUP);  // Exit Sensor for Spot 3
  
  // Initialize LED pin as output
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW); // Ensure LED is off initially
  
  // Initialize Servo
  myservo.attach(SERVO_PIN);
  myservo.write(0); // Initialize servo at 0 degrees
  
  // Initialize LCD
  lcd.init();
  lcd.backlight();
  
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Hello...");
  lcd.setCursor(0, 1);
  lcd.print("Please wait...");
  delay(10000); // Wait for 10 seconds
  lcd.clear();
}

// Function to check if parking is full
bool isParkingFull() {
  // Check if all spots are taken
  for (int i = 0; i < maxSpots; i++) {
    if (spots[i] == -1) {
      return false;  // If there's an empty spot
    }
  }
  return true;  // All spots are full
}

// Function to check if a specific spot is occupied
bool isSpotOccupied(int spotNumber) {
  // Check if the entered spot is already occupied
  for (int i = 0; i < maxSpots; i++) {
    if (spots[i] == spotNumber) {
      return true;  // Spot is occupied
    }
  }
  return false;  // Spot is not occupied
}// Function to add a new spot
void addSpot(int spotNumber) {
  // Add the spot to the array
  for (int i = 0; i < maxSpots; i++) {
    if (spots[i] == -1) {  // Find the first empty spot
      spots[i] = spotNumber;  // Assign the spot number to the array
      Serial.print("Spot ");
      Serial.print(spotNumber);
      Serial.println(" has been reserved.");
      
      // Update LCD
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Spot ");
      lcd.print(spotNumber);
      lcd.print(" reserved");
      delay(2000);  // Show the reserved message for 2 seconds
      break;
    }
  }
}

// Function to remove a spot when a car exits
void removeSpot(int spotNumber) {
  // Find and remove the spot from the array
  for (int i = 0; i < maxSpots; i++) {
    if (spots[i] == spotNumber) {
      spots[i] = -1; // Mark the spot as available
      Serial.print("Spot ");
      Serial.print(spotNumber);
      Serial.println(" has been freed.");
      
      // Update LCD
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Spot ");
      lcd.print(spotNumber);
      lcd.print(" is free");
      delay(2000);  // Show the freed message for 2 seconds
      break;
    }
  }
}